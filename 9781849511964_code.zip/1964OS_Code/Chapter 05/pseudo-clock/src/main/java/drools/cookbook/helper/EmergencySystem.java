package drools.cookbook.helper;

/**
 * 
 * @author Lucas Amador
 * 
 */
public class EmergencySystem {

    public static void sendFireTrucks() {
        System.out.println("-> Fire trucks sended");
    }

    public static void sendAmbulances() {
        System.out.println("-> Ambulances sended");
    }

    public static void cleanRunways() {
        System.out.println("-> Cleaning runways in progress");
    }

}
