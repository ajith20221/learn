package drools.cookbook.chapter02;

/**
 * 
 * @author Lucas Amador
 *
 */
public enum ServiceType {

    HTTP,
    FTP,
    SSH;

}
