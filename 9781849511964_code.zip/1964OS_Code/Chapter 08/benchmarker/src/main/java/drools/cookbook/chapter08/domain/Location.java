package drools.cookbook.chapter08.domain;

public enum Location {

    SAN_DIEGO, MONTANA, NY, NORTH_CAROLINA, WASHINGTON_DC

}
