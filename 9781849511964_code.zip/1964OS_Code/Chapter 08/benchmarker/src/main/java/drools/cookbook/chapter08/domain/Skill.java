package drools.cookbook.chapter08.domain;

public enum Skill {

    JAVA, SCALA, REST, DROOLS, HADOOP;

}
