package drools.cookbook.chapter08.domain;

/**
 * 
 * @author Lucas Amador
 * 
 */
public enum Skill {

    JAVA, SCALA, REST, DROOLS, HADOOP;

}
