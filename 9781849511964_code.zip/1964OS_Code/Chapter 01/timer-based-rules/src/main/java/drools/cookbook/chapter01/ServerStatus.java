package drools.cookbook.chapter01;

public enum ServerStatus {

    ONLINE,
    OFFLINE,
    MAINTENANCE;

}
